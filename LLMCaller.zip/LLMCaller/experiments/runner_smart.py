import time
import asyncio
from datetime import datetime
from config.loader import load_category_variables
from config.validator import validate_llm_setup
from logs.setup import setup_logging
from storage.saver import save_attempt
from storage.summarizer import update_summary
from api.api_factory import create_api_client
from validation.validator import ResponseValidator
from prompts.generator import generate_prompt
from usage.tracker import DailyUsageTracker
from utils.smart_queue import SmartQueue, create_experiment_executor
import random

class SmartExperimentRunner:
    """
    Enhanced experiment runner using the smart queue system for optimal API call batching.
    
    This runner replaces the old batching system with a sophisticated queue that:
    - Prioritizes retries over new tasks
    - Uses cross-model work stealing to fill batches
    - Always hits the rate limit exactly (no wasted API calls)
    - Handles multiple models efficiently
    """
    
    def __init__(self, run_dir, config, batch_size=15):
        self.run_dir = run_dir
        self.logger = setup_logging(run_dir)
        self.config = self._validate_config(config)
        self.usage_tracker = DailyUsageTracker()
        self.batch_size = batch_size
        
        # Initialize smart queue with configurable rate limit
        self.smart_queue = SmartQueue(rate_limit=batch_size, logger=self.logger)
        
    def _validate_config(self, config):
        validate_llm_setup(config)
        return config

    def run_experiment(self):
        """Run experiment synchronously - wrapper for async implementation"""
        asyncio.run(self._run_experiment_async())
    
    async def _run_experiment_async(self):
        """Run experiment for a single model using smart queue"""
        self.logger.info(f"Smart experiment run started at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Load all experiments for this model
        categories_variables = load_category_variables()
        all_pairs = [(category, variable) for category, variables in categories_variables.items() for variable in variables]
        random.shuffle(all_pairs)
        
        total_experiments = len(all_pairs)
        self.logger.info(f"Total experiments to run: {total_experiments}")
        
        # Pre-flight safety check
        can_run, usage_info = self.usage_tracker.can_run_experiments(total_experiments)
        if not can_run:
            error_msg = f"Cannot run {total_experiments} experiments - would exceed daily limit!"
            error_msg += f"\nCurrent usage: {usage_info['current_usage']}/{usage_info['daily_limit']}"
            error_msg += f"\nRemaining: {usage_info['remaining']}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        
        self.logger.info(f"Pre-flight check passed: {usage_info['current_usage']} + {total_experiments} = {usage_info['total_after']}/{usage_info['daily_limit']}")
        
        # Pre-flight rate limit check
        print("🔍 Checking current rate limit status...")
        rate_limit_ready = await self.api_client.wait_for_rate_limit_reset()
        if not rate_limit_ready:
            error_msg = "Pre-flight rate limit check failed - aborting experiments"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        
        # Create executor for this model
        executor = await self._create_model_executor()
        
        # Add all experiments to the smart queue
        model_name = self.config.get('model', 'unknown_model')
        self.smart_queue.add_model_tasks(model_name, all_pairs, executor)
        
        # Process all experiments using smart queue
        results = await self.smart_queue.process_all()
        
        # Record the run in usage tracker
        smart_stats = results['stats']
        await self.usage_tracker.record_run(
            calls_made=smart_stats['completed_tasks'],
            models_count=1,  # Single model per run
            experiments_count=total_experiments,
            metadata={
                'queue_system': 'smart_queue',
                'total_batches': smart_stats['batches_processed'],
                'success_rate': f"{smart_stats['completed_tasks']}/{total_experiments}",
                'efficiency_percent': smart_stats['efficiency_percent'],
                'wasted_slots': smart_stats['wasted_slots'],
                'total_time_minutes': smart_stats['total_time_minutes']
            }
        )
        
        # Print final summary
        usage_summary = await self._get_usage_summary()
        self.logger.info(f"API Usage Summary: {usage_summary}")
        self.logger.info(f"Smart Queue Stats: {smart_stats}")
        
        print(f"\n🎉 Smart experiment run completed!")
        print(f"   Total experiments: {total_experiments}")
        print(f"   Completed: {smart_stats['completed_tasks']}")
        print(f"   Failed: {smart_stats['failed_tasks']}")
        print(f"   Retries: {smart_stats['retry_tasks']}")
        print(f"   Total time: {smart_stats['total_time_minutes']:.1f} minutes")
        print(f"   Efficiency: {smart_stats['efficiency_percent']:.1f}% ({smart_stats['wasted_slots']} wasted slots)")
        print(f"   API calls tracked: {usage_summary}")
        
        self.logger.info(f"Smart experiment run completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        return results
    
    async def _create_model_executor(self):
        """Create an executor function for this model's experiments"""
        api_client = create_api_client(self.config, rate_limit=self.batch_size)
        validator = ResponseValidator()
        max_attempts = self.config.get('max_attempts', 3)
        
        async def executor(experiment_pair):
            """Execute a single experiment - smart queue handles retries"""
            if len(experiment_pair) == 3:
                category, variable, attempt_number = experiment_pair
            else:
                # Backward compatibility for old calls
                category, variable = experiment_pair
                attempt_number = 1
            prompt = generate_prompt(category, variable)
            
            api_response = None
            try:
                # Call the API
                api_response = await api_client.generate_response(prompt)
                
                # Validate response (with safety wrapper for JSON errors)
                response_content = api_response.choices[0].message.content
                try:
                    is_valid, message, extracted_data = validator.validate_response(response_content, category)
                except Exception as validation_exception:
                    # Validator itself threw an exception - treat as validation failure
                    is_valid = False
                    message = f"Validation error: {str(validation_exception)}"
                    extracted_data = None
                
                # Prepare result with full API response regardless of validation
                result = {
                    "category": category,
                    "variable": variable,
                    "prompt": prompt,
                    "full_api_response": api_response.model_dump(),
                    "validation_result": {
                        "is_valid": is_valid,
                        "message": message,
                        "extracted_data": extracted_data
                    },
                    "attempt": attempt_number  # Smart queue tracks actual attempt numbers
                }
                
                # ALWAYS save result first (with full API response) regardless of validation
                result_path = save_attempt(result, self.run_dir)
                summary_path = update_summary(result, self.run_dir)
                
                if is_valid:
                    self.logger.info(f"✅ Success: {category}:{variable} - {result_path}")
                    return result
                else:
                    self.logger.info(f"❌ Invalid (will retry): {category}:{variable} - {message} - Saved: {result_path}")
                    # Throw exception to trigger retry, but we already saved the full API response above
                    raise Exception(f"Validation failed: {message}")
                    
            except Exception as e:
                # Check if this is a validation failure (already saved above) or a real API error
                if "Validation failed:" in str(e):
                    # This is a validation failure - we already saved the full response above
                    # Just re-raise to trigger retry
                    self.logger.error(f"🔄 Validation failed (already saved): {category}:{variable} - {str(e)}")
                    raise e
                
                # This is a real API error - save error result with API response if available
                error_result = {
                    "category": category,
                    "variable": variable,
                    "prompt": prompt,
                    "attempt": attempt_number,
                    "error": {
                        "error_type": type(e).__name__,
                        "message": str(e)
                    },
                    "validation_result": {
                        "is_valid": False,
                        "message": "Error occurred during API call",
                        "extracted_data": None
                    }
                }
                
                # ALWAYS save whatever we got back - API response AND exception details
                if api_response is not None:
                    # API call succeeded, save the full response for debugging
                    error_result["full_api_response"] = api_response.model_dump()
                    # Also save what went wrong during processing
                    error_result["processing_error"] = {
                        "error_type": type(e).__name__,
                        "message": str(e),
                        "note": "API call succeeded but processing failed (e.g., JSON parsing)"
                    }
                else:
                    # API call itself failed - save exception details
                    error_result["full_api_response"] = {
                        "error_from_exception": str(e),
                        "exception_type": type(e).__name__,
                        "raw_exception": str(e),
                        "note": "API call itself failed"
                    }
                
                result_path = save_attempt(error_result, self.run_dir)
                update_summary(error_result, self.run_dir)
                self.logger.error(f"❌ API Error: {category}:{variable} - {str(e)} - Saved: {result_path}")
                raise e
        
        return executor
    
    async def _get_usage_summary(self):
        """Get usage summary from API client"""
        # Create a temporary API client to get usage summary
        api_client = create_api_client(self.config)
        return api_client.get_usage_summary()
    
    def run_single_experiment(self, category, variable):
        """Run experiment for a single category-variable pair"""
        asyncio.run(self._run_single_experiment_async(category, variable))
    
    async def _run_single_experiment_async(self, category, variable):
        """Run experiment for a single category-variable pair using smart queue"""
        self.logger.info(f"Single smart experiment started for {category}: {variable} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Pre-flight rate limit check
        api_client = create_api_client(self.config)
        print("🔍 Checking current rate limit status...")
        rate_limit_ready = await api_client.wait_for_rate_limit_reset()
        if not rate_limit_ready:
            error_msg = "Pre-flight rate limit check failed - aborting experiment"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        
        # Create executor
        executor = await self._create_model_executor()
        
        # Add single task to smart queue
        model_name = self.config.get('model', 'unknown_model')
        self.smart_queue.add_model_tasks(model_name, [(category, variable)], executor)
        
        # Process the single task
        results = await self.smart_queue.process_all()
        
        # Print usage summary
        usage_summary = await self._get_usage_summary()
        self.logger.info(f"Usage Summary: {usage_summary}")
        print(f"\nUsage Summary: {usage_summary}")
        print(f"Smart Queue Stats: {results['stats']}")
        
        self.logger.info(f"Single smart experiment completed for {category}: {variable} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        return results

class MultiModelSmartRunner:
    """
    Runner for multiple models using the smart queue system.
    
    This is where the real magic happens - it can run multiple models
    with optimal cross-model work stealing and batch filling.
    """
    
    def __init__(self, output_dir=None, batch_size=15, temperature_override=None):
        self.output_dir = output_dir or "experiments"
        self.usage_tracker = DailyUsageTracker()
        self.batch_size = batch_size
        self.temperature_override = temperature_override
        self.smart_queue = SmartQueue(rate_limit=batch_size)
    
    async def run_all_models_smart(self, models, category=None, variable=None):
        """
        Run experiments for multiple models using smart cross-model batching.
        
        This is the optimal implementation that fills batches across models.
        """
        from config.loader import load_llm_setup, load_category_variables
        from main import create_experiment_config
        
        print(f"\n🚀 Starting smart multi-model run with {len(models)} models")
        
        # Simple logging
        if hasattr(self.smart_queue, 'simple_logger') and self.smart_queue.simple_logger:
            self.smart_queue.simple_logger.log(f"Starting smart multi-model run with {len(models)} models")
        
        # Pre-flight rate limit check using first model
        if models:
            first_model_config = load_llm_setup(models[0])
            api_client = create_api_client(first_model_config)
            print("🔍 Checking current rate limit status...")
            rate_limit_ready = await api_client.wait_for_rate_limit_reset()
            if not rate_limit_ready:
                error_msg = "Pre-flight rate limit check failed - aborting multi-model experiments"
                print(f"❌ {error_msg}")
                raise Exception(error_msg)
        
        # Load all experiments
        if category and variable:
            all_pairs = [(category, variable)]
        else:
            categories_variables = load_category_variables()
            all_pairs = [(cat, var) for cat, variables in categories_variables.items() for var in variables]
            random.shuffle(all_pairs)
        
        total_experiments = len(all_pairs) * len(models)
        print(f"📊 Total experiments across all models: {total_experiments}")
        
        # Simple logging
        if hasattr(self.smart_queue, 'simple_logger') and self.smart_queue.simple_logger:
            self.smart_queue.simple_logger.log(f"Total experiments: {total_experiments}")
        
        # Pre-flight check
        can_run, usage_info = self.usage_tracker.can_run_experiments(total_experiments)
        if not can_run:
            error_msg = f"Cannot run {total_experiments} experiments - would exceed daily limit!"
            error_msg += f"\nCurrent usage: {usage_info['current_usage']}/{usage_info['daily_limit']}"
            error_msg += f"\nRemaining: {usage_info['remaining']}"
            print(f"❌ {error_msg}")
            raise Exception(error_msg)
        
        print(f"✅ Pre-flight check passed: {usage_info['current_usage']} + {total_experiments} = {usage_info['total_after']}/{usage_info['daily_limit']}")
        
        # Simple logging and daily stats tracking
        if hasattr(self.smart_queue, 'simple_logger') and self.smart_queue.simple_logger:
            self.smart_queue.simple_logger.log(f"Pre-flight check passed: {usage_info['current_usage']} + {total_experiments} = {usage_info['total_after']}/{usage_info['daily_limit']}")
            
            # Record pre-flight check in daily stats
            self.smart_queue.simple_logger.record_pre_flight_check(
                current_usage=usage_info['current_usage'],
                planned_calls=total_experiments,
                daily_limit=usage_info['daily_limit']
            )
        
        # Create executors for each model
        model_executors = {}
        for model in models:
            run_dir, config = create_experiment_config(model, self.output_dir, self.temperature_override)
            executor = await self._create_model_executor(run_dir, config)
            model_executors[model] = executor
            
            # Add model tasks to smart queue
            self.smart_queue.add_model_tasks(model, all_pairs, executor)
            print(f"➕ Added {len(all_pairs)} tasks for {model}")
            
            # Simple logging
            if hasattr(self.smart_queue, 'simple_logger') and self.smart_queue.simple_logger:
                self.smart_queue.simple_logger.log(f"Added {len(all_pairs)} tasks for {model}")
        
        # Process all models using smart queue
        print(f"\n🔄 Processing all models with smart cross-model batching...")
        
        # Simple logging
        if hasattr(self.smart_queue, 'simple_logger') and self.smart_queue.simple_logger:
            self.smart_queue.simple_logger.log("Processing all models with smart cross-model batching")
        
        results = await self.smart_queue.process_all()
        
        # Record the run
        smart_stats = results['stats']
        await self.usage_tracker.record_run(
            calls_made=smart_stats['completed_tasks'],
            models_count=len(models),
            experiments_count=total_experiments,
            metadata={
                'queue_system': 'smart_queue_multi_model',
                'models': models,
                'total_batches': smart_stats['batches_processed'],
                'success_rate': f"{smart_stats['completed_tasks']}/{total_experiments}",
                'efficiency_percent': smart_stats['efficiency_percent'],
                'wasted_slots': smart_stats['wasted_slots'],
                'total_time_minutes': smart_stats['total_time_minutes']
            }
        )
        
        # Print final summary
        print(f"\n🎉 Smart multi-model run completed!")
        print(f"   Models: {len(models)}")
        print(f"   Total experiments: {total_experiments}")
        print(f"   Completed: {smart_stats['completed_tasks']}")
        print(f"   Failed: {smart_stats['failed_tasks']}")
        print(f"   Retries: {smart_stats['retry_tasks']}")
        print(f"   Total time: {smart_stats['total_time_minutes']:.1f} minutes")
        print(f"   Efficiency: {smart_stats['efficiency_percent']:.1f}% ({smart_stats['wasted_slots']} wasted slots)")
        print(f"   Average time per model: {smart_stats['total_time_minutes']/len(models):.1f} minutes")
        
        # Simple logging final summary
        if hasattr(self.smart_queue, 'simple_logger') and self.smart_queue.simple_logger:
            self.smart_queue.simple_logger.log("Smart multi-model run completed!")
            self.smart_queue.simple_logger.log(f"Models: {len(models)}")
            self.smart_queue.simple_logger.log(f"Total experiments: {total_experiments}")
            self.smart_queue.simple_logger.log(f"Completed: {smart_stats['completed_tasks']}, Failed: {smart_stats['failed_tasks']}, Retries: {smart_stats['retry_tasks']}")
            self.smart_queue.simple_logger.log(f"Total time: {smart_stats['total_time_minutes']:.1f} minutes")
            self.smart_queue.simple_logger.log(f"Efficiency: {smart_stats['efficiency_percent']:.1f}% ({smart_stats['wasted_slots']} wasted slots)")
            self.smart_queue.simple_logger.log(f"Average time per model: {smart_stats['total_time_minutes']/len(models):.1f} minutes")
        
        # Show efficiency improvement
        old_estimated_time = len(models) * len(all_pairs)  # Old system: 1 minute per batch worst case
        time_saved = max(0, old_estimated_time - smart_stats['total_time_minutes'])
        print(f"   🚀 Estimated time saved vs old system: {time_saved:.1f} minutes ({time_saved/60:.1f} hours)")
        
        return results
    
    async def _create_model_executor(self, run_dir, config):
        """Create executor for a specific model"""
        api_client = create_api_client(config, rate_limit=self.batch_size)
        validator = ResponseValidator()
        
        async def executor(experiment_pair):
            if len(experiment_pair) == 3:
                category, variable, attempt_number = experiment_pair
            else:
                # Backward compatibility for old calls
                category, variable = experiment_pair
                attempt_number = 1
            prompt = generate_prompt(category, variable)
            
            api_response = None
            try:
                # Call the API
                api_response = await api_client.generate_response(prompt)
                
                # Validate response (with safety wrapper for JSON errors)
                response_content = api_response.choices[0].message.content
                try:
                    is_valid, message, extracted_data = validator.validate_response(response_content, category)
                except Exception as validation_exception:
                    # Validator itself threw an exception - treat as validation failure
                    is_valid = False
                    message = f"Validation error: {str(validation_exception)}"
                    extracted_data = None
                
                # ALWAYS prepare and save result with full API response (Option B!)
                result = {
                    "category": category,
                    "variable": variable,
                    "prompt": prompt,
                    "full_api_response": api_response.model_dump(),
                    "validation_result": {
                        "is_valid": is_valid,
                        "message": message,
                        "extracted_data": extracted_data
                    },
                    "attempt": attempt_number
                }
                
                # ALWAYS save result first
                save_attempt(result, run_dir)
                update_summary(result, run_dir)
                
                if is_valid:
                    return result
                else:
                    # Validation failed - but we already saved the full response above
                    raise Exception(f"Validation failed: {message}")
                
            except Exception as e:
                # Check if this is a validation failure (already saved above) or a real API error
                if "Validation failed:" in str(e):
                    # This is a validation failure - we already saved the full response above
                    raise e
                
                # This is a real API error - save error result with API response if available
                error_result = {
                    "category": category,
                    "variable": variable,
                    "prompt": prompt,
                    "attempt": attempt_number,
                    "error": {
                        "error_type": type(e).__name__,
                        "message": str(e)
                    },
                    "validation_result": {
                        "is_valid": False,
                        "message": "Error occurred during API call",
                        "extracted_data": None
                    }
                }
                
                # ALWAYS save whatever we got back - API response AND exception details
                if api_response is not None:
                    # API call succeeded, save the full response for debugging
                    error_result["full_api_response"] = api_response.model_dump()
                    # Also save what went wrong during processing
                    error_result["processing_error"] = {
                        "error_type": type(e).__name__,
                        "message": str(e),
                        "note": "API call succeeded but processing failed (e.g., JSON parsing)"
                    }
                else:
                    # API call itself failed - save exception details
                    error_result["full_api_response"] = {
                        "error_from_exception": str(e),
                        "exception_type": type(e).__name__,
                        "raw_exception": str(e),
                        "note": "API call itself failed"
                    }
                
                save_attempt(error_result, run_dir)
                update_summary(error_result, run_dir)
                raise e
        
        return executor